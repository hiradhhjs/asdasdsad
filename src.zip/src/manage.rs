use axum::{extract::State, http::StatusCode, Json};
use redis::AsyncCommands;
use validator::Validate;

use crate::{
    internal_error,
    user::{User, UserLoginData},
    AppState,
};

pub async fn count_user(
    State(mut state): State<AppState>,
    Json(payload): Json<UserLoginData>,
) -> Result<(StatusCode, String), (StatusCode, String)> {
    payload
        .validate()
        .map_err(|e| (StatusCode::BAD_REQUEST, format!("Bad Request: {}", e)))?;

    if !state
        .connection
        .exists(format!("user:{}", payload.username))
        .await
        .map_err(internal_error)?
    {
        return Err((StatusCode::NOT_FOUND, String::from("User Doesn't Exists")));
    }

    let user: User = state
        .connection
        .get(format!("user:{}", payload.username))
        .await
        .map_err(internal_error)?;

    if user.token != payload.token {
        return Err((
            StatusCode::UNAUTHORIZED,
            String::from("Password doesn't match"),
        ));
    }

    if !user.admin {
        return Err((
            StatusCode::UNAUTHORIZED,
            String::from("You aren't an admin"),
        ));
    }

    let keys: Vec<String> = state
        .connection
        .keys("user:*")
        .await
        .map_err(internal_error)?;

    Ok((StatusCode::OK, keys.len().to_string()))
}

pub async fn count_post(
    State(mut state): State<AppState>,
    Json(payload): Json<UserLoginData>,
) -> Result<(StatusCode, String), (StatusCode, String)> {
    payload
        .validate()
        .map_err(|e| (StatusCode::BAD_REQUEST, format!("Bad Request: {}", e)))?;

    if !state
        .connection
        .exists(format!("user:{}", payload.username))
        .await
        .map_err(internal_error)?
    {
        return Err((StatusCode::NOT_FOUND, String::from("User Doesn't Exists")));
    }

    let user: User = state
        .connection
        .get(format!("user:{}", payload.username))
        .await
        .map_err(internal_error)?;

    if user.token != payload.token {
        return Err((
            StatusCode::UNAUTHORIZED,
            String::from("Password doesn't match"),
        ));
    }

    if !user.admin {
        return Err((
            StatusCode::UNAUTHORIZED,
            String::from("You aren't an admin"),
        ));
    }

    let keys: Vec<String> = state
        .connection
        .keys("post:*")
        .await
        .map_err(internal_error)?;

    Ok((StatusCode::OK, keys.len().to_string()))
}

pub async fn count_slider(
    State(mut state): State<AppState>,
    Json(payload): Json<UserLoginData>,
) -> Result<(StatusCode, String), (StatusCode, String)> {
    payload
        .validate()
        .map_err(|e| (StatusCode::BAD_REQUEST, format!("Bad Request: {}", e)))?;

    if !state
        .connection
        .exists(format!("user:{}", payload.username))
        .await
        .map_err(internal_error)?
    {
        return Err((StatusCode::NOT_FOUND, String::from("User Doesn't Exists")));
    }

    let user: User = state
        .connection
        .get(format!("user:{}", payload.username))
        .await
        .map_err(internal_error)?;

    if user.token != payload.token {
        return Err((
            StatusCode::UNAUTHORIZED,
            String::from("Password doesn't match"),
        ));
    }

    if !user.admin {
        return Err((
            StatusCode::UNAUTHORIZED,
            String::from("You aren't an admin"),
        ));
    }

    let keys: Vec<String> = state
        .connection
        .keys("slider:*")
        .await
        .map_err(internal_error)?;

    Ok((StatusCode::OK, keys.len().to_string()))
}
