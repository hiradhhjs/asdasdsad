use axum::{extract::State, http::StatusCode, Json};
use redis::AsyncCommands;
use redis_macros::{FromRedisValue, ToRedisArgs};
use serde::{Deserialize, Serialize};
use validator::Validate;

use crate::{
    internal_error,
    user::{User, UserLoginData},
    AppState,
};

#[derive(Serialize, Deserialize, Eq, PartialEq, Validate)]
pub struct CreateSlider {
    login_data: UserLoginData,
    name: String,
    tag: String,
}

#[derive(Serialize, Deserialize, Eq, PartialEq, FromRedisValue, ToRedisArgs, Clone)]
pub struct Slider {
    pub name: String,
    pub tag: String,
}

pub async fn create_slider(
    State(mut state): State<AppState>,
    Json(payload): Json<CreateSlider>,
) -> Result<StatusCode, (StatusCode, String)> {
    payload
        .validate()
        .map_err(|e| (StatusCode::BAD_REQUEST, format!("Bad Request: {}", e)))?;

    if !state
        .connection
        .exists(format!("user:{}", payload.login_data.username))
        .await
        .map_err(internal_error)?
    {
        return Err((StatusCode::NOT_FOUND, String::from("User Doesn't Exists")));
    }

    let user: User = state
        .connection
        .get(format!("user:{}", payload.login_data.username))
        .await
        .map_err(internal_error)?;

    if user.token != payload.login_data.token {
        return Err((
            StatusCode::UNAUTHORIZED,
            String::from("Password doesn't match"),
        ));
    }

    if !user.admin {
        return Err((
            StatusCode::UNAUTHORIZED,
            String::from("You aren't an admin"),
        ));
    }

    if state
        .connection
        .exists(format!("slider:{}", payload.name.clone()))
        .await
        .map_err(internal_error)?
    {
        return Err((StatusCode::CONFLICT, String::from("Slider Already Exists")));
    }

    let keys: Vec<String> = state
        .connection
        .keys("slider:*")
        .await
        .map_err(internal_error)?;

    for key in keys {
        let slider: Slider = state.connection.get(key).await.map_err(internal_error)?;
        if slider.tag == payload.tag {
            return Err((
                StatusCode::CONFLICT,
                String::from("Slider Tag Already Exists"),
            ));
        }
    }

    let slider = Slider {
        name: payload.name.clone(),
        tag: payload.tag,
    };

    state
        .connection
        .set(format!("slider:{}", payload.name), slider)
        .await
        .map_err(internal_error)?;

    state.cache_handler.slider_cache.lock().await.take();

    Ok(StatusCode::OK)
}

#[derive(Serialize, Deserialize, Eq, PartialEq, Validate)]
pub struct DeleteSlider {
    login_data: UserLoginData,
    name: String,
}

pub async fn delete_slider(
    State(mut state): State<AppState>,
    Json(payload): Json<DeleteSlider>,
) -> Result<StatusCode, (StatusCode, String)> {
    payload
        .validate()
        .map_err(|e| (StatusCode::BAD_REQUEST, format!("Bad Request: {}", e)))?;

    if !state
        .connection
        .exists(format!("user:{}", payload.login_data.username))
        .await
        .map_err(internal_error)?
    {
        return Err((StatusCode::NOT_FOUND, String::from("User Doesn't Exists")));
    }

    let user: User = state
        .connection
        .get(format!("user:{}", payload.login_data.username))
        .await
        .map_err(internal_error)?;

    if user.token != payload.login_data.token {
        return Err((
            StatusCode::UNAUTHORIZED,
            String::from("Password doesn't match"),
        ));
    }

    if !user.admin {
        return Err((
            StatusCode::UNAUTHORIZED,
            String::from("You aren't an admin"),
        ));
    }

    if !state
        .connection
        .exists(format!("slider:{}", payload.name.clone()))
        .await
        .map_err(internal_error)?
    {
        return Err((StatusCode::NOT_FOUND, String::from("Slider Doesn't Exists")));
    }

    state
        .connection
        .del(format!("slider:{}", payload.name.clone()))
        .await
        .map_err(internal_error)?;

    state.cache_handler.slider_cache.lock().await.take();

    Ok(StatusCode::OK)
}

pub async fn list_slider(
    State(mut state): State<AppState>,
) -> Result<(StatusCode, Json<Vec<Slider>>), (StatusCode, String)> {
    let sliders = state.cache_handler.slider_cache.lock().await.clone();
    if let Some(sliders) = sliders {
        Ok((StatusCode::OK, Json(sliders)))
    } else {
        let keys: Vec<String> = state
            .connection
            .keys("slider:*")
            .await
            .map_err(internal_error)?;

        let mut sliders: Vec<Slider> = Vec::new();
        for key in keys {
            let slider = state.connection.get(key).await.map_err(internal_error)?;
            sliders.push(slider);
        }

        *state.cache_handler.slider_cache.lock().await = Some(sliders.clone());

        Ok((StatusCode::OK, Json(sliders)))
    }
}
