use std::io::{BufWriter, Write};

use axum::{extract::State, http::StatusCode, Json};
use base64::{engine::general_purpose, Engine};
use image::{codecs::avif::AvifEncoder, imageops::FilterType, ColorType, ImageEncoder};
use redis::{aio::ConnectionManager, AsyncCommands};
use redis_macros::{FromRedisValue, ToRedisArgs};
use serde::{Deserialize, Serialize};
use tracing::warn;
use validator::Validate;

use crate::{
    discord::send_webhook,
    internal_error, internal_error_boxed,
    user::{User, UserLoginData},
    AppState,
};

#[derive(Serialize, Deserialize, Debug, Eq, PartialEq, FromRedisValue, ToRedisArgs, Clone)]
pub struct Post {
    pub image: Option<Vec<u8>>,
    pub file: Option<Vec<u8>>,
    pub name: String,
    pub price: u32,
    pub discounted_price: Option<u32>,
    pub author: String,
    pub slider_tag: String,
    pub title: String,
    pub description: String,
    pub in_stock: u32,
    pub score: u32,
    pub r#type: String,
}

#[derive(Serialize, Deserialize, Eq, PartialEq, Validate)]
pub struct CreatePost {
    login_data: UserLoginData,
    image: Option<String>,
    force_image: bool,
    file: Option<String>,
    force_file: bool,
    name: String,
    price: u32,
    discounted_price: Option<u32>,
    author: String,
    slider_tag: String,
    title: String,
    description: String,
    in_stock: u32,
    score: u32,
    r#type: String,
    edit: Option<String>,
}

pub async fn create_post(
    State(mut state): State<AppState>,
    Json(payload): Json<CreatePost>,
) -> Result<StatusCode, (StatusCode, String)> {
    payload
        .validate()
        .map_err(|e| (StatusCode::BAD_REQUEST, format!("Bad Request: {}", e)))?;

    if !state
        .connection
        .exists(format!("user:{}", payload.login_data.username))
        .await
        .map_err(internal_error)?
    {
        return Err((StatusCode::NOT_FOUND, String::from("User Doesn't Exists")));
    }

    let user: User = state
        .connection
        .get(format!("user:{}", payload.login_data.username))
        .await
        .map_err(internal_error)?;

    if user.token != payload.login_data.token {
        return Err((
            StatusCode::UNAUTHORIZED,
            String::from("Password doesn't match"),
        ));
    }

    if !user.admin {
        return Err((
            StatusCode::UNAUTHORIZED,
            String::from("You aren't an admin"),
        ));
    }

    if payload.r#type == "کتاب صوتی" && payload.file.is_none() && payload.force_file {
        return Err((StatusCode::BAD_REQUEST, String::from("File can't be null")));
    }

    if payload.r#type == "کتاب فیزیکی" && payload.file.is_some() {
        return Err((StatusCode::BAD_REQUEST, String::from("File should be null")));
    }

    if payload.r#type == "کتاب الکترونیکی" && payload.file.is_none() && payload.force_file
    {
        return Err((StatusCode::BAD_REQUEST, String::from("File can't be null")));
    }

    let previous = if payload.edit.is_some() {
        if !state
            .connection
            .exists(format!("post:{}", payload.edit.clone().unwrap()))
            .await
            .map_err(internal_error)?
        {
            return Err((StatusCode::NOT_FOUND, String::from("Post Doesn't Exists")));
        }

        let post: Post = state
            .connection
            .get(format!("post:{}", payload.edit.clone().unwrap()))
            .await
            .map_err(internal_error)?;

        Some(post)
    } else {
        if state
            .connection
            .exists(format!("post:{}", payload.name.clone()))
            .await
            .map_err(internal_error)?
        {
            return Err((StatusCode::CONFLICT, String::from("Post Already Exists")));
        }

        None
    };

    let image = if payload.image.is_some() {
        let image = general_purpose::STANDARD
            .decode(payload.image.unwrap())
            .map_err(internal_error)?;
        let image = image::load_from_memory(&image).map_err(internal_error)?;
        let image = image.resize_exact(600, 800, FilterType::Gaussian);

        let mut image_webp = BufWriter::new(Vec::new());
        AvifEncoder::new_with_speed_quality(&mut image_webp, 4, 30)
            .write_image(
                image.as_bytes(),
                image.width(),
                image.height(),
                ColorType::Rgb8,
            )
            .map_err(internal_error)?;
        image_webp.flush().map_err(internal_error)?;

        let image_webp = image_webp.into_inner().map_err(internal_error)?;

        Some(image_webp)
    } else {
        None
    };

    let file = if payload.file.is_some() {
        Some(
            general_purpose::STANDARD
                .decode(payload.file.unwrap())
                .map_err(internal_error)?,
        )
    } else {
        None
    };

    #[allow(clippy::unnecessary_unwrap)]
    let post = Post {
        image: if previous.clone().is_some() && image.is_none() && !payload.force_image {
            previous.clone().unwrap().image
        } else {
            image
        },
        file: if previous.is_some() && file.is_none() && !payload.force_file {
            previous.unwrap().file
        } else {
            file
        },
        name: payload.name.clone(),
        price: payload.price,
        discounted_price: payload.discounted_price,
        author: payload.author,
        slider_tag: payload.slider_tag,
        title: payload.title,
        description: payload.description,
        in_stock: payload.in_stock,
        score: payload.score,
        r#type: payload.r#type,
    };

    if payload.edit.is_some() {
        state
            .connection
            .del(format!("post:{}", payload.edit.clone().unwrap()))
            .await
            .map_err(internal_error)?;
    }

    state
        .connection
        .set(format!("post:{}", payload.name), post.clone())
        .await
        .map_err(internal_error)?;

    state.cache_handler.list_posts_cache.invalidate_all();
    state.cache_handler.posts_cache.invalidate_all();
    state.cache_handler.cache_size.invalidate_all();

    tokio::spawn(async move {
        if let Err(e) = send_webhook(post).await {
            warn!("Failed to send backup: {e}");
        }
    });

    Ok(StatusCode::OK)
}

#[derive(Serialize, Deserialize, Eq, PartialEq, Validate)]
pub struct DeletePost {
    login_data: UserLoginData,
    name: String,
}

pub async fn delete_post(
    State(mut state): State<AppState>,
    Json(payload): Json<DeletePost>,
) -> Result<StatusCode, (StatusCode, String)> {
    payload
        .validate()
        .map_err(|e| (StatusCode::BAD_REQUEST, format!("Bad Request: {}", e)))?;

    if !state
        .connection
        .exists(format!("user:{}", payload.login_data.username))
        .await
        .map_err(internal_error)?
    {
        return Err((StatusCode::NOT_FOUND, String::from("User Doesn't Exists")));
    }

    let user: User = state
        .connection
        .get(format!("user:{}", payload.login_data.username))
        .await
        .map_err(internal_error)?;

    if user.token != payload.login_data.token {
        return Err((
            StatusCode::UNAUTHORIZED,
            String::from("Password doesn't match"),
        ));
    }

    if !user.admin {
        return Err((
            StatusCode::UNAUTHORIZED,
            String::from("You aren't an admin"),
        ));
    }

    if !state
        .connection
        .exists(format!("post:{}", payload.name.clone()))
        .await
        .map_err(internal_error)?
    {
        return Err((StatusCode::NOT_FOUND, String::from("Post Doesn't Exists")));
    }

    state
        .connection
        .del(format!("post:{}", payload.name.clone()))
        .await
        .map_err(internal_error)?;

    state.cache_handler.list_posts_cache.invalidate_all();
    state.cache_handler.posts_cache.invalidate_all();
    state.cache_handler.cache_size.invalidate_all();

    Ok(StatusCode::OK)
}

#[derive(Serialize, Deserialize, Eq, PartialEq, Validate)]
pub struct ModifyPrice {
    login_data: UserLoginData,
    name: String,
    price: u32,
}

pub async fn modify_price(
    State(mut state): State<AppState>,
    Json(payload): Json<ModifyPrice>,
) -> Result<StatusCode, (StatusCode, String)> {
    payload
        .validate()
        .map_err(|e| (StatusCode::BAD_REQUEST, format!("Bad Request: {}", e)))?;

    if !state
        .connection
        .exists(format!("user:{}", payload.login_data.username))
        .await
        .map_err(internal_error)?
    {
        return Err((StatusCode::NOT_FOUND, String::from("User Doesn't Exists")));
    }

    let user: User = state
        .connection
        .get(format!("user:{}", payload.login_data.username))
        .await
        .map_err(internal_error)?;

    if user.token != payload.login_data.token {
        return Err((
            StatusCode::UNAUTHORIZED,
            String::from("Password doesn't match"),
        ));
    }

    if !user.admin {
        return Err((
            StatusCode::UNAUTHORIZED,
            String::from("You aren't an admin"),
        ));
    }

    if !state
        .connection
        .exists(format!("post:{}", payload.name.clone()))
        .await
        .map_err(internal_error)?
    {
        return Err((StatusCode::NOT_FOUND, String::from("Post Doesn't Exists")));
    }

    let mut post: Post = state
        .connection
        .get(format!("post:{}", payload.name.clone()))
        .await
        .map_err(internal_error)?;

    post.price = payload.price;

    state
        .connection
        .set(format!("post:{}", payload.name), post)
        .await
        .map_err(internal_error)?;

    state.cache_handler.list_posts_cache.invalidate_all();
    state.cache_handler.posts_cache.invalidate_all();

    Ok(StatusCode::OK)
}

#[derive(Serialize, Deserialize, Eq, PartialEq, Validate)]
pub struct ModifyDiscount {
    login_data: UserLoginData,
    name: String,
    discount: Option<u32>,
}

pub async fn modify_discount(
    State(mut state): State<AppState>,
    Json(payload): Json<ModifyDiscount>,
) -> Result<StatusCode, (StatusCode, String)> {
    payload
        .validate()
        .map_err(|e| (StatusCode::BAD_REQUEST, format!("Bad Request: {}", e)))?;

    if !state
        .connection
        .exists(format!("user:{}", payload.login_data.username))
        .await
        .map_err(internal_error)?
    {
        return Err((StatusCode::NOT_FOUND, String::from("User Doesn't Exists")));
    }

    let user: User = state
        .connection
        .get(format!("user:{}", payload.login_data.username))
        .await
        .map_err(internal_error)?;

    if user.token != payload.login_data.token {
        return Err((
            StatusCode::UNAUTHORIZED,
            String::from("Password doesn't match"),
        ));
    }

    if !user.admin {
        return Err((
            StatusCode::UNAUTHORIZED,
            String::from("You aren't an admin"),
        ));
    }

    if !state
        .connection
        .exists(format!("post:{}", payload.name.clone()))
        .await
        .map_err(internal_error)?
    {
        return Err((StatusCode::NOT_FOUND, String::from("Post Doesn't Exists")));
    }

    let mut post: Post = state
        .connection
        .get(format!("post:{}", payload.name.clone()))
        .await
        .map_err(internal_error)?;

    post.discounted_price = payload.discount;

    state
        .connection
        .set(format!("post:{}", payload.name), post)
        .await
        .map_err(internal_error)?;

    state.cache_handler.list_posts_cache.invalidate_all();
    state.cache_handler.posts_cache.invalidate_all();

    Ok(StatusCode::OK)
}

#[derive(Serialize, Deserialize, Eq, PartialEq, Validate)]
pub struct ModifyStock {
    login_data: UserLoginData,
    name: String,
    in_stock: u32,
}

pub async fn modify_stock(
    State(mut state): State<AppState>,
    Json(payload): Json<ModifyStock>,
) -> Result<StatusCode, (StatusCode, String)> {
    payload
        .validate()
        .map_err(|e| (StatusCode::BAD_REQUEST, format!("Bad Request: {}", e)))?;

    if !state
        .connection
        .exists(format!("user:{}", payload.login_data.username))
        .await
        .map_err(internal_error)?
    {
        return Err((StatusCode::NOT_FOUND, String::from("User Doesn't Exists")));
    }

    let user: User = state
        .connection
        .get(format!("user:{}", payload.login_data.username))
        .await
        .map_err(internal_error)?;

    if user.token != payload.login_data.token {
        return Err((
            StatusCode::UNAUTHORIZED,
            String::from("Password doesn't match"),
        ));
    }

    if !user.admin {
        return Err((
            StatusCode::UNAUTHORIZED,
            String::from("You aren't an admin"),
        ));
    }

    if !state
        .connection
        .exists(format!("post:{}", payload.name.clone()))
        .await
        .map_err(internal_error)?
    {
        return Err((StatusCode::NOT_FOUND, String::from("Post Doesn't Exists")));
    }

    let mut post: Post = state
        .connection
        .get(format!("post:{}", payload.name.clone()))
        .await
        .map_err(internal_error)?;

    post.in_stock = payload.in_stock;

    state
        .connection
        .set(format!("post:{}", payload.name), post)
        .await
        .map_err(internal_error)?;

    state.cache_handler.list_posts_cache.invalidate_all();
    state.cache_handler.posts_cache.invalidate_all();

    Ok(StatusCode::OK)
}

#[derive(Serialize, Deserialize, Eq, PartialEq, Validate)]
pub struct ListPost {
    #[validate(range(min = 0, max = 30))]
    page_number: u32,
    #[validate(range(min = 0, max = 30))]
    image_per_page: u32,
    null_image: Option<bool>,
    only_in_stock: Option<bool>,
    only_out_of_stock: Option<bool>,
    only_discounted: Option<bool>,
    tag: Option<String>,
    r#type: Option<String>,
}

#[derive(Serialize, Deserialize, Eq, PartialEq)]
pub struct ListPostResponse {
    posts: Vec<Post>,
    count: u32,
}

pub async fn list_post(
    State(state): State<AppState>,
    Json(payload): Json<ListPost>,
) -> Result<(StatusCode, Json<ListPostResponse>), (StatusCode, String)> {
    payload
        .validate()
        .map_err(|e| (StatusCode::BAD_REQUEST, format!("Bad Request: {}", e)))?;

    let posts = if let Some(posts) = state
        .cache_handler
        .list_posts_cache
        .get(&(
            payload.page_number,
            payload.image_per_page,
            payload.null_image.unwrap_or(false),
            payload.only_in_stock.unwrap_or(false),
            payload.only_out_of_stock.unwrap_or(false),
            payload.only_discounted.unwrap_or(false),
            payload.tag.clone(),
            payload.r#type.clone(),
        ))
        .await
    {
        posts
    } else {
        let posts = get_posts(
            state.connection.clone(),
            payload.page_number,
            payload.image_per_page,
            payload.null_image.unwrap_or(false),
            payload.only_in_stock.unwrap_or(false),
            payload.only_out_of_stock.unwrap_or(false),
            payload.only_discounted.unwrap_or(false),
            payload.tag.clone(),
            payload.r#type.clone(),
        )
        .await
        .map_err(internal_error_boxed)?;

        state
            .cache_handler
            .list_posts_cache
            .insert(
                (
                    payload.page_number,
                    payload.image_per_page,
                    payload.null_image.unwrap_or(false),
                    payload.only_in_stock.unwrap_or(false),
                    payload.only_out_of_stock.unwrap_or(false),
                    payload.only_discounted.unwrap_or(false),
                    payload.tag.clone(),
                    payload.r#type.clone(),
                ),
                posts.clone(),
            )
            .await;

        posts
    };

    let list_size = if let Some(posts) = state
        .cache_handler
        .cache_size
        .get(&(
            payload.only_in_stock,
            payload.only_discounted,
            payload.tag.clone(),
            payload.r#type.clone(),
        ))
        .await
    {
        posts
    } else {
        let list_size = get_posts_size(
            state.connection,
            payload.only_in_stock,
            payload.only_out_of_stock,
            payload.only_discounted,
            payload.tag.clone(),
            payload.r#type.clone(),
        )
        .await
        .map_err(internal_error_boxed)?;

        state
            .cache_handler
            .cache_size
            .insert(
                (
                    payload.only_in_stock,
                    payload.only_discounted,
                    payload.tag.clone(),
                    payload.r#type.clone(),
                ),
                list_size,
            )
            .await;

        list_size
    };

    Ok((
        StatusCode::OK,
        Json(ListPostResponse {
            posts,
            count: list_size as u32,
        }),
    ))
}

#[derive(Serialize, Deserialize, Eq, PartialEq)]
pub struct GetPost {
    name: String,
}

pub async fn get_post(
    State(mut state): State<AppState>,
    Json(payload): Json<GetPost>,
) -> Result<(StatusCode, Json<Post>), (StatusCode, String)> {
    if let Some(post) = state.cache_handler.posts_cache.get(&payload.name).await {
        Ok((StatusCode::OK, Json(post)))
    } else {
        if !state
            .connection
            .exists(format!("post:{}", payload.name.clone()))
            .await
            .map_err(internal_error)?
        {
            return Err((StatusCode::NOT_FOUND, String::from("Post Doesn't Exists")));
        }

        let post: Post = state
            .connection
            .get(format!("post:{}", payload.name.clone()))
            .await
            .map_err(internal_error)?;

        state
            .cache_handler
            .posts_cache
            .insert(payload.name, post.clone())
            .await;

        Ok((StatusCode::OK, Json(post)))
    }
}

#[allow(clippy::too_many_arguments)]
pub async fn get_posts(
    mut connection: ConnectionManager,
    page_number: u32,
    image_per_page: u32,
    null_image: bool,
    only_in_stock: bool,
    only_out_of_stock: bool,
    only_discounted: bool,
    tag: Option<String>,
    r#type: Option<String>,
) -> Result<Vec<Post>, Box<dyn std::error::Error + Send + Sync + 'static>> {
    let mut keys: Vec<String> = connection.keys("post:*").await?;
    keys.sort_unstable();

    let image_per_page = if image_per_page == 1 {
        99999
    } else {
        image_per_page
    };

    let mut posts: Vec<Post> = Vec::new();
    let start_index = (page_number.checked_sub(1).ok_or("")? * image_per_page) as usize;

    for key in keys.iter().skip(start_index).take(image_per_page as usize) {
        let mut post: Post = connection.get(key).await?;

        if null_image {
            post.image = None;
        }

        post.file = None;

        if only_in_stock && post.in_stock == 0 {
            continue;
        }

        if only_out_of_stock && post.in_stock != 0 {
            continue;
        }

        if only_discounted && post.discounted_price.is_none() {
            continue;
        }

        if let Some(tag) = tag.clone() {
            if post.slider_tag != tag {
                continue;
            }
        }

        if let Some(r#type) = r#type.clone() {
            if post.r#type != r#type {
                continue;
            }
        }

        post.file = None;
        posts.push(post);
    }

    Ok(posts)
}

#[derive(Serialize, Deserialize, Eq, PartialEq)]
pub struct SearchPost {
    query: String,
    null_image: Option<bool>,
    only_in_stock: Option<bool>,
    only_out_of_stock: Option<bool>,
    only_discounted: Option<bool>,
    tag: Option<String>,
    r#type: Option<String>,
}

pub async fn search_post(
    State(state): State<AppState>,
    Json(payload): Json<SearchPost>,
) -> Result<(StatusCode, Json<Vec<Post>>), (StatusCode, String)> {
    let mut posts = if let Some(posts) = state
        .cache_handler
        .list_posts_cache
        .get(&(
            1,
            99999,
            payload.null_image.unwrap_or(false),
            payload.only_in_stock.unwrap_or(false),
            payload.only_out_of_stock.unwrap_or(false),
            payload.only_discounted.unwrap_or(false),
            payload.tag.clone(),
            payload.r#type.clone(),
        ))
        .await
    {
        posts
    } else {
        let posts = get_posts(
            state.connection,
            1,
            99999,
            payload.null_image.unwrap_or(false),
            payload.only_in_stock.unwrap_or(false),
            payload.only_out_of_stock.unwrap_or(false),
            payload.only_discounted.unwrap_or(false),
            payload.tag.clone(),
            payload.r#type.clone(),
        )
        .await
        .map_err(internal_error_boxed)?;

        state
            .cache_handler
            .list_posts_cache
            .insert(
                (
                    1,
                    99999,
                    payload.null_image.unwrap_or(false),
                    payload.only_in_stock.unwrap_or(false),
                    payload.only_out_of_stock.unwrap_or(false),
                    payload.only_discounted.unwrap_or(false),
                    payload.tag.clone(),
                    payload.r#type.clone(),
                ),
                posts.clone(),
            )
            .await;

        posts
    };

    posts.retain(|post| {
        post.name.contains(&payload.query)
            || post.author.contains(&payload.query)
            || post.title.contains(&payload.query)
            || post.description.contains(&payload.query)
    });

    Ok((StatusCode::OK, Json(posts)))
}

pub async fn get_posts_size(
    mut connection: ConnectionManager,
    only_in_stock: Option<bool>,
    only_out_of_stock: Option<bool>,
    only_discounted: Option<bool>,
    tag: Option<String>,
    r#type: Option<String>,
) -> Result<usize, Box<dyn std::error::Error + Send + Sync + 'static>> {
    let keys: Vec<String> = connection.keys("post:*").await?;

    let mut post_size = 0;

    for key in keys.iter() {
        let post: Post = connection.get(key).await?;

        if only_in_stock.unwrap_or(false) && post.in_stock == 0 {
            continue;
        }

        if only_out_of_stock.unwrap_or(false) && post.in_stock != 0 {
            continue;
        }

        if only_discounted.unwrap_or(false) && post.discounted_price.is_none() {
            continue;
        }

        if let Some(tag_value) = &tag {
            if post.slider_tag != *tag_value {
                continue;
            }
        }

        if let Some(type_value) = &r#type {
            if post.r#type != *type_value {
                continue;
            }
        }

        post_size += 1;
    }

    Ok(post_size)
}
