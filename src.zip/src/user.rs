use std::collections::HashMap;

use rand::{distributions::Alphanumeric, Rng};

use axum::{extract::State, http::StatusCode, Json};
use redis::AsyncCommands;
use redis_macros::{FromRedisValue, ToRedisArgs};
use serde::{Deserialize, Serialize};
use validator::Validate;

use crate::{
    internal_error, internal_error_boxed,
    posts::Post,
    sms::{send_reset_password_code, send_verify_code},
    AppState,
};

#[derive(Serialize, Deserialize, Eq, PartialEq, Validate)]
pub struct CreateUser {
    #[validate(length(min = 6, max = 30))]
    username: String,
    #[validate(length(min = 6, max = 30))]
    password: String,
    #[validate(length(min = 10, max = 11))]
    phone_number: String,
}

pub async fn create_user(
    State(mut state): State<AppState>,
    Json(payload): Json<CreateUser>,
) -> Result<(StatusCode, String), (StatusCode, String)> {
    payload
        .validate()
        .map_err(|e| (StatusCode::BAD_REQUEST, format!("Bad Request: {}", e)))?;

    if state
        .connection
        .exists(format!("user:{}", payload.username))
        .await
        .map_err(internal_error)?
    {
        return Err((StatusCode::CONFLICT, String::from("Username already taken")));
    }

    if payload.phone_number.parse::<u64>().is_err() || !payload.phone_number.starts_with("09") {
        return Err((
            StatusCode::BAD_REQUEST,
            String::from("Username already taken"),
        ));
    }

    let keys: Vec<String> = state
        .connection
        .keys("user:*")
        .await
        .map_err(internal_error)?;

    for key in keys {
        let user: User = state.connection.get(key).await.map_err(internal_error)?;

        if user.phone_number == payload.phone_number {
            return Err((
                StatusCode::CONFLICT,
                String::from("Phone number already taken"),
            ));
        }
    }

    let user = User {
        username: payload.username.clone(),
        password: payload.password,
        phone_number: payload.phone_number,
        token: rand::thread_rng()
            .sample_iter(&Alphanumeric)
            .take(18)
            .map(char::from)
            .collect(),
        admin: false,
        cart: HashMap::new(),
        bought: Vec::new(),
        address_info: None,
        orders: Vec::new(),
    };

    let verification_token = rand::thread_rng()
        .sample_iter(&Alphanumeric)
        .take(18)
        .map(char::from)
        .collect::<String>();
    let verification_code: u64 = rand::thread_rng().gen_range(100_000..999_999);

    state.verification.lock().await.insert(
        (verification_token.clone(), verification_code),
        user.clone(),
    );

    if state
        .phone_number_time_limit
        .lock()
        .await
        .contains(&user.phone_number)
    {
        return Err((
            StatusCode::TOO_MANY_REQUESTS,
            String::from("Too many requests"),
        ));
    }

    send_verify_code(verification_code, &user.phone_number)
        .await
        .map_err(internal_error_boxed)?;

    state
        .phone_number_time_limit
        .lock()
        .await
        .push(user.phone_number.clone());

    tokio::spawn(async move {
        tokio::time::sleep(tokio::time::Duration::from_secs(60 * 3)).await;
        state
            .phone_number_time_limit
            .lock()
            .await
            .retain(|phone_number| phone_number != &user.phone_number);
    });

    Ok((StatusCode::OK, verification_token))
}

#[derive(Serialize, Deserialize, Eq, PartialEq, Validate)]
pub struct VerifyUser {
    #[validate(length(min = 18, max = 18))]
    verification_token: String,
    verification_code: u64,
}

pub async fn verify_user(
    State(mut state): State<AppState>,
    Json(payload): Json<VerifyUser>,
) -> Result<StatusCode, (StatusCode, String)> {
    payload
        .validate()
        .map_err(|e| (StatusCode::BAD_REQUEST, format!("Bad Request: {}", e)))?;

    let mut verification = state.verification.lock().await;
    let user = verification.get(&(
        payload.verification_token.clone(),
        payload.verification_code,
    ));

    if user.is_none() {
        return Err((
            StatusCode::NOT_FOUND,
            String::from("Verification token or code is wrong"),
        ));
    };

    let user = user.unwrap();

    state
        .connection
        .set(format!("user:{}", user.username), user)
        .await
        .map_err(internal_error)?;

    verification.remove(&(payload.verification_token, payload.verification_code));

    Ok(StatusCode::OK)
}

#[derive(Serialize, Deserialize, Eq, PartialEq)]
pub struct ResetPassword {
    username: Option<String>,
    phone_number: Option<String>,
}

pub async fn reset_password(
    State(mut state): State<AppState>,
    Json(payload): Json<ResetPassword>,
) -> Result<StatusCode, (StatusCode, String)> {
    let user: User = if let Some(username) = payload.username.clone() {
        if !state
            .connection
            .exists(format!("user:{}", username))
            .await
            .map_err(internal_error)?
        {
            return Err((
                StatusCode::NOT_FOUND,
                String::from("Username doesn't exist"),
            ));
        }

        state
            .connection
            .get(format!("user:{}", username))
            .await
            .map_err(internal_error)?
    } else if let Some(phone_number) = payload.phone_number.clone() {
        let keys: Vec<String> = state
            .connection
            .keys("user:*")
            .await
            .map_err(internal_error)?;

        let mut user = None;

        for key in keys {
            let temp_user: User = state.connection.get(key).await.map_err(internal_error)?;

            if temp_user.phone_number == phone_number {
                user = Some(temp_user);
                break;
            }
        }

        if user.is_none() {
            return Err((
                StatusCode::NOT_FOUND,
                String::from("Phone number doesn't exist"),
            ));
        }

        user.unwrap()
    } else {
        return Err((
            StatusCode::BAD_REQUEST,
            String::from("Username or phone number must be provided"),
        ));
    };

    let verification_token = rand::thread_rng()
        .sample_iter(&Alphanumeric)
        .take(18)
        .map(char::from)
        .collect::<String>();

    state
        .reset_password_verification
        .lock()
        .await
        .insert(verification_token.clone(), user.clone());

    let thread_reset_password_verification = state.reset_password_verification.clone();
    let thread_verification_token = verification_token.clone();
    tokio::spawn(async move {
        tokio::time::sleep(tokio::time::Duration::from_secs(60 * 30)).await;
        thread_reset_password_verification
            .lock()
            .await
            .remove(&thread_verification_token);
    });

    if state
        .phone_number_time_limit
        .lock()
        .await
        .contains(&user.phone_number)
    {
        return Err((
            StatusCode::TOO_MANY_REQUESTS,
            String::from("Too many requests"),
        ));
    }

    send_reset_password_code(&user.username, &verification_token, &user.phone_number)
        .await
        .map_err(internal_error_boxed)?;

    state
        .phone_number_time_limit
        .lock()
        .await
        .push(user.phone_number.clone());

    tokio::spawn(async move {
        tokio::time::sleep(tokio::time::Duration::from_secs(60 * 3)).await;
        state
            .phone_number_time_limit
            .lock()
            .await
            .retain(|phone_number| phone_number != &user.phone_number);
    });

    Ok(StatusCode::CREATED)
}

#[derive(Serialize, Deserialize, Eq, PartialEq, Validate)]
pub struct VerifyResetPassword {
    #[validate(length(min = 18, max = 18))]
    verification_token: String,
    #[validate(length(min = 6, max = 30))]
    password: String,
}

pub async fn verify_reset_password(
    State(mut state): State<AppState>,
    Json(payload): Json<VerifyResetPassword>,
) -> Result<(StatusCode, Json<UserLoginData>), (StatusCode, String)> {
    payload
        .validate()
        .map_err(|e| (StatusCode::BAD_REQUEST, format!("Bad Request: {}", e)))?;

    let mut verification = state.reset_password_verification.lock().await;
    let user = verification.get(&(payload.verification_token.clone()));

    if user.is_none() {
        return Err((
            StatusCode::NOT_FOUND,
            String::from("Verification token or code is wrong"),
        ));
    };
    let user = user.unwrap();

    let verification_token = rand::thread_rng()
        .sample_iter(&Alphanumeric)
        .take(18)
        .map(char::from)
        .collect::<String>();

    let user = User {
        username: user.username.clone(),
        password: payload.password.clone(),
        phone_number: user.phone_number.clone(),
        token: verification_token,
        admin: user.admin,
        cart: user.cart.clone(),
        bought: user.bought.clone(),
        address_info: None,
        orders: Vec::new(),
    };

    let user_login_data = UserLoginData {
        username: user.username.clone(),
        token: user.token.clone(),
    };

    state
        .connection
        .set(format!("user:{}", user.username), user)
        .await
        .map_err(internal_error)?;

    verification.remove(&(payload.verification_token));

    Ok((StatusCode::OK, Json(user_login_data)))
}

#[derive(Serialize, Deserialize, Eq, PartialEq, Validate)]
pub struct IsResetPasswordVerificationTokenValid {
    #[validate(length(min = 18, max = 18))]
    verification_token: String,
}

pub async fn is_reset_password_verification_token_valid(
    State(state): State<AppState>,
    Json(payload): Json<IsResetPasswordVerificationTokenValid>,
) -> Result<StatusCode, (StatusCode, String)> {
    payload
        .validate()
        .map_err(|e| (StatusCode::BAD_REQUEST, format!("Bad Request: {}", e)))?;

    let verification = state.reset_password_verification.lock().await;
    let user = verification.get(&(payload.verification_token.clone()));

    if user.is_none() {
        return Err((
            StatusCode::NOT_FOUND,
            String::from("Verification token or code is wrong"),
        ));
    };

    Ok(StatusCode::OK)
}

#[derive(Serialize, Deserialize, Eq, PartialEq, Validate)]
pub struct LoginUser {
    #[validate(length(min = 6, max = 30))]
    username: String,
    #[validate(length(min = 6, max = 30))]
    password: String,
}

pub async fn login_user(
    State(mut state): State<AppState>,
    Json(payload): Json<LoginUser>,
) -> Result<(StatusCode, String), (StatusCode, String)> {
    payload
        .validate()
        .map_err(|e| (StatusCode::BAD_REQUEST, format!("Bad Request: {}", e)))?;

    if !state
        .connection
        .exists(format!("user:{}", payload.username))
        .await
        .map_err(internal_error)?
    {
        return Err((
            StatusCode::NOT_FOUND,
            String::from("Username doesn't exist"),
        ));
    }

    let user: User = state
        .connection
        .get(format!("user:{}", payload.username))
        .await
        .map_err(internal_error)?;

    if user.password != payload.password {
        return Err((
            StatusCode::UNAUTHORIZED,
            String::from("Password doesn't match"),
        ));
    }

    Ok((StatusCode::OK, user.token))
}

#[derive(
    Serialize, Deserialize, PartialEq, Eq, FromRedisValue, ToRedisArgs, Clone, Debug, Validate,
)]
pub struct AddressInfo {
    #[validate(length(min = 3, max = 30))]
    name: String,
    #[validate(length(min = 3, max = 30))]
    last_name: String,
    #[validate(length(min = 3, max = 30))]
    province: String,
    #[validate(length(min = 3, max = 30))]
    city: String,
    #[validate(length(min = 3, max = 30))]
    postal_code: String,
    #[validate(length(min = 10, max = 11))]
    phone_number: String,
    #[validate(length(min = 3, max = 60))]
    address: String,
}

#[derive(
    Serialize, Deserialize, PartialEq, Eq, FromRedisValue, ToRedisArgs, Clone, Debug, Validate,
)]
pub struct Order {
    pub date: String,
    pub products: HashMap<String, u32>,
    pub address_info: AddressInfo,
    pub stage: String,
    pub order_id: u32,
}

#[derive(Serialize, Deserialize, FromRedisValue, ToRedisArgs, Clone, Debug, Validate)]
pub struct User {
    #[validate(length(min = 6, max = 30))]
    pub username: String,
    #[validate(length(min = 6, max = 30))]
    pub password: String,
    #[validate(length(min = 10, max = 11))]
    pub phone_number: String,
    #[validate(length(min = 18, max = 18))]
    pub token: String,
    pub admin: bool,
    pub cart: HashMap<String, u32>,
    pub bought: Vec<Post>,
    pub address_info: Option<AddressInfo>,
    pub orders: Vec<Order>,
}

#[derive(Serialize, Deserialize, Clone, Debug, Eq, PartialEq, Validate)]
pub struct UserLoginData {
    #[validate(length(min = 6, max = 30))]
    pub username: String,
    #[validate(length(min = 18, max = 18))]
    pub token: String,
}

pub async fn is_admin(
    State(mut state): State<AppState>,
    Json(payload): Json<UserLoginData>,
) -> Result<(StatusCode, String), (StatusCode, String)> {
    payload
        .validate()
        .map_err(|e| (StatusCode::BAD_REQUEST, format!("Bad Request: {}", e)))?;

    if !state
        .connection
        .exists(format!("user:{}", payload.username))
        .await
        .map_err(internal_error)?
    {
        return Err((StatusCode::NOT_FOUND, String::from("User Doesn't Exists")));
    }

    let user: User = state
        .connection
        .get(format!("user:{}", payload.username))
        .await
        .map_err(internal_error)?;

    if user.token != payload.token {
        return Err((
            StatusCode::UNAUTHORIZED,
            String::from("Password doesn't match"),
        ));
    }

    Ok((StatusCode::OK, user.admin.to_string()))
}

#[derive(Serialize, Deserialize, Eq, PartialEq, Validate)]
pub struct SetAddressInfo {
    login_data: UserLoginData,
    #[validate(length(min = 3, max = 30))]
    name: String,
    #[validate(length(min = 3, max = 30))]
    last_name: String,
    #[validate(length(min = 3, max = 30))]
    province: String,
    #[validate(length(min = 3, max = 30))]
    city: String,
    #[validate(length(min = 3, max = 30))]
    postal_code: String,
    #[validate(length(min = 10, max = 11))]
    phone_number: String,
    #[validate(length(min = 3, max = 60))]
    address: String,
}

pub async fn set_address_info(
    State(mut state): State<AppState>,
    Json(payload): Json<SetAddressInfo>,
) -> Result<StatusCode, (StatusCode, String)> {
    payload
        .validate()
        .map_err(|e| (StatusCode::BAD_REQUEST, format!("Bad Request: {}", e)))?;

    if !state
        .connection
        .exists(format!("user:{}", payload.login_data.username))
        .await
        .map_err(internal_error)?
    {
        return Err((StatusCode::NOT_FOUND, String::from("User Doesn't Exists")));
    }

    let user: User = state
        .connection
        .get(format!("user:{}", payload.login_data.username))
        .await
        .map_err(internal_error)?;

    if user.token != payload.login_data.token {
        return Err((
            StatusCode::UNAUTHORIZED,
            String::from("Password doesn't match"),
        ));
    }

    let user = User {
        address_info: Some(AddressInfo {
            name: payload.name.clone(),
            last_name: payload.last_name.clone(),
            province: payload.province.clone(),
            city: payload.city.clone(),
            postal_code: payload.postal_code.clone(),
            phone_number: payload.phone_number.clone(),
            address: payload.address.clone(),
        }),
        ..user
    };

    state
        .connection
        .set(format!("user:{}", user.username), user)
        .await
        .map_err(internal_error)?;

    Ok(StatusCode::OK)
}

#[derive(Serialize, Deserialize, Eq, PartialEq, Validate)]
pub struct GetAddressInfo {
    login_data: UserLoginData,
}

pub async fn get_address_info(
    State(mut state): State<AppState>,
    Json(payload): Json<GetAddressInfo>,
) -> Result<(StatusCode, Json<AddressInfo>), (StatusCode, String)> {
    payload
        .validate()
        .map_err(|e| (StatusCode::BAD_REQUEST, format!("Bad Request: {}", e)))?;

    if !state
        .connection
        .exists(format!("user:{}", payload.login_data.username))
        .await
        .map_err(internal_error)?
    {
        return Err((StatusCode::NOT_FOUND, String::from("User Doesn't Exists")));
    }

    let user: User = state
        .connection
        .get(format!("user:{}", payload.login_data.username))
        .await
        .map_err(internal_error)?;

    if user.token != payload.login_data.token {
        return Err((
            StatusCode::UNAUTHORIZED,
            String::from("Password doesn't match"),
        ));
    }

    if user.address_info.is_none() {
        return Err((
            StatusCode::NOT_FOUND,
            String::from("Address Info Doesn't Exists"),
        ));
    }

    Ok((StatusCode::OK, Json(user.address_info.unwrap())))
}
