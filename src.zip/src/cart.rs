use std::collections::HashMap;

use axum::{extract::State, http::StatusCode, Json};
use chrono::Utc;
use rand::Rng;
use redis::AsyncCommands;
use serde::{Deserialize, Serialize};
use validator::Validate;

use crate::{
    internal_error, internal_error_boxed,
    posts::{get_posts, Post},
    user::{Order, User, UserLoginData},
    AppState,
};

#[derive(Serialize, Deserialize, Eq, PartialEq, Validate)]
pub struct AddToCart {
    login_data: UserLoginData,
    name: String,
}

pub async fn add_to_cart(
    State(mut state): State<AppState>,
    Json(payload): Json<AddToCart>,
) -> Result<StatusCode, (StatusCode, String)> {
    payload
        .validate()
        .map_err(|e| (StatusCode::BAD_REQUEST, format!("Bad Request: {}", e)))?;

    if !state
        .connection
        .exists(format!("user:{}", payload.login_data.username))
        .await
        .map_err(internal_error)?
    {
        return Err((StatusCode::NOT_FOUND, String::from("User Doesn't Exists")));
    }

    let mut user: User = state
        .connection
        .get(format!("user:{}", payload.login_data.username))
        .await
        .map_err(internal_error)?;

    if user.token != payload.login_data.token {
        return Err((
            StatusCode::UNAUTHORIZED,
            String::from("Password doesn't match"),
        ));
    }

    if !state
        .connection
        .exists(format!("post:{}", payload.name.clone()))
        .await
        .map_err(internal_error)?
    {
        return Err((StatusCode::NOT_FOUND, String::from("Post Doesn't Exists")));
    }

    let post: Post = state
        .connection
        .get(format!("post:{}", payload.name.clone()))
        .await
        .map_err(internal_error)?;

    let count = user.cart.get(&payload.name);
    if let Some(count) = count {
        let max_count = if post.r#type == "کتاب فیزیکی" {
            5
        } else {
            1
        };

        if *count < max_count {
            user.cart.insert(payload.name, count + 1);
        } else {
            return Err((
                StatusCode::INSUFFICIENT_STORAGE,
                String::from("Password doesn't match"),
            ));
        }
    } else {
        user.cart.insert(payload.name, 1);
    }

    state
        .connection
        .set(format!("user:{}", user.username), user)
        .await
        .map_err(internal_error)?;

    Ok(StatusCode::OK)
}

#[derive(Serialize, Deserialize, Eq, PartialEq, Validate)]
pub struct DeleteFromCart {
    login_data: UserLoginData,
    name: String,
}

pub async fn delete_from_cart(
    State(mut state): State<AppState>,
    Json(payload): Json<DeleteFromCart>,
) -> Result<StatusCode, (StatusCode, String)> {
    payload
        .validate()
        .map_err(|e| (StatusCode::BAD_REQUEST, format!("Bad Request: {}", e)))?;

    if !state
        .connection
        .exists(format!("user:{}", payload.login_data.username))
        .await
        .map_err(internal_error)?
    {
        return Err((StatusCode::NOT_FOUND, String::from("User Doesn't Exists")));
    }

    let mut user: User = state
        .connection
        .get(format!("user:{}", payload.login_data.username))
        .await
        .map_err(internal_error)?;

    if user.token != payload.login_data.token {
        return Err((
            StatusCode::UNAUTHORIZED,
            String::from("Password doesn't match"),
        ));
    }

    let count = user.cart.get(&payload.name);
    if let Some(count) = count {
        if *count > 0 {
            user.cart.insert(payload.name, count - 1);
        } else {
            user.cart.remove(&payload.name);
        }
    } else {
        return Err((
            StatusCode::NOT_FOUND,
            String::from("No such a item in shopping cart"),
        ));
    }

    state
        .connection
        .set(format!("user:{}", user.username), user)
        .await
        .map_err(internal_error)?;

    Ok(StatusCode::OK)
}

pub async fn list_cart(
    State(mut state): State<AppState>,
    Json(payload): Json<UserLoginData>,
) -> Result<(StatusCode, Json<HashMap<String, u32>>), (StatusCode, String)> {
    payload
        .validate()
        .map_err(|e| (StatusCode::BAD_REQUEST, format!("Bad Request: {}", e)))?;

    if !state
        .connection
        .exists(format!("user:{}", payload.username))
        .await
        .map_err(internal_error)?
    {
        return Err((StatusCode::NOT_FOUND, String::from("User Doesn't Exists")));
    }

    let user: User = state
        .connection
        .get(format!("user:{}", payload.username))
        .await
        .map_err(internal_error)?;

    if user.token != payload.token {
        return Err((
            StatusCode::UNAUTHORIZED,
            String::from("Password doesn't match"),
        ));
    }

    Ok((StatusCode::OK, Json(user.cart)))
}

#[derive(Serialize, Deserialize, Eq, PartialEq, Validate)]
pub struct DeleteAllFromCart {
    login_data: UserLoginData,
    name: String,
}

pub async fn delete_all_from_cart(
    State(mut state): State<AppState>,
    Json(payload): Json<DeleteFromCart>,
) -> Result<StatusCode, (StatusCode, String)> {
    payload
        .validate()
        .map_err(|e| (StatusCode::BAD_REQUEST, format!("Bad Request: {}", e)))?;

    if !state
        .connection
        .exists(format!("user:{}", payload.login_data.username))
        .await
        .map_err(internal_error)?
    {
        return Err((StatusCode::NOT_FOUND, String::from("User Doesn't Exists")));
    }

    let mut user: User = state
        .connection
        .get(format!("user:{}", payload.login_data.username))
        .await
        .map_err(internal_error)?;

    if user.token != payload.login_data.token {
        return Err((
            StatusCode::UNAUTHORIZED,
            String::from("Password doesn't match"),
        ));
    }

    user.cart.remove(&payload.name);

    state
        .connection
        .set(format!("user:{}", user.username), user)
        .await
        .map_err(internal_error)?;

    Ok(StatusCode::OK)
}

#[derive(Serialize, Deserialize, Eq, PartialEq, Validate)]
pub struct GetCartPrice {
    login_data: UserLoginData,
    name: Option<String>,
}

#[derive(Serialize, Deserialize, Eq, PartialEq)]
pub struct CartPrice {
    price: u32,
    discounted_price: u32,
}

pub async fn get_cart_price(
    State(mut state): State<AppState>,
    Json(payload): Json<GetCartPrice>,
) -> Result<(StatusCode, Json<CartPrice>), (StatusCode, String)> {
    payload
        .validate()
        .map_err(|e| (StatusCode::BAD_REQUEST, format!("Bad Request: {}", e)))?;

    if !state
        .connection
        .exists(format!("user:{}", payload.login_data.username))
        .await
        .map_err(internal_error)?
    {
        return Err((StatusCode::NOT_FOUND, String::from("User Doesn't Exists")));
    }

    let user: User = state
        .connection
        .get(format!("user:{}", payload.login_data.username))
        .await
        .map_err(internal_error)?;

    if user.token != payload.login_data.token {
        return Err((
            StatusCode::UNAUTHORIZED,
            String::from("Password doesn't match"),
        ));
    }

    let posts = get_posts(
        state.connection,
        1,
        99999,
        false,
        false,
        false,
        false,
        None,
        None,
    )
    .await
    .map_err(internal_error_boxed)?;

    let mut price = 0;
    let mut discounted_price = 0;
    for (name, count) in user.cart {
        let mut found = false;
        for post in &posts {
            if post.name == name {
                price += post.price * count;
                discounted_price += post.discounted_price.unwrap_or(post.price) * count;
                found = true;
                break;
            }
        }

        if !found {
            return Err((StatusCode::NOT_FOUND, String::from("Product was not found")));
        }
    }

    let cart_price = CartPrice {
        price,
        discounted_price,
    };

    Ok((StatusCode::OK, Json(cart_price)))
}

#[derive(Serialize, Deserialize, Eq, PartialEq, Validate)]
pub struct BuyCart {
    login_data: UserLoginData,
}

pub async fn buy_cart(
    State(mut state): State<AppState>,
    Json(payload): Json<BuyCart>,
) -> Result<StatusCode, (StatusCode, String)> {
    payload
        .validate()
        .map_err(|e| (StatusCode::BAD_REQUEST, format!("Bad Request: {}", e)))?;

    if !state
        .connection
        .exists(format!("user:{}", payload.login_data.username))
        .await
        .map_err(internal_error)?
    {
        return Err((StatusCode::NOT_FOUND, String::from("User Doesn't Exists")));
    }

    let mut user: User = state
        .connection
        .get(format!("user:{}", payload.login_data.username))
        .await
        .map_err(internal_error)?;

    if user.token != payload.login_data.token {
        return Err((
            StatusCode::UNAUTHORIZED,
            String::from("Password doesn't match"),
        ));
    }

    let posts = get_posts(
        state.connection.clone(),
        1,
        99999,
        false,
        false,
        false,
        false,
        None,
        None,
    )
    .await
    .map_err(internal_error_boxed)?;

    let mut ordered_posts = HashMap::new();
    for (name, count) in user.cart.clone() {
        let mut found = false;
        for post in &posts {
            if post.name == name {
                if post.in_stock < count {
                    return Err((
                        StatusCode::INSUFFICIENT_STORAGE,
                        String::from("Not enough stock"),
                    ));
                }

                ordered_posts.insert(post.name.clone(), count);

                found = true;
                break;
            }
        }

        if !found {
            return Err((StatusCode::NOT_FOUND, String::from("Product was not found")));
        }
    }

    if user.address_info.is_none() {
        return Err((
            StatusCode::BAD_REQUEST,
            String::from("Address info is not set"),
        ));
    }

    user.orders.push(Order {
        date: Utc::now().to_rfc2822(),
        products: ordered_posts,
        address_info: user.address_info.clone().unwrap(),
        stage: String::from("درحال آماده سازی"),
        order_id: rand::thread_rng().gen_range(100_000..999_999),
    });
    user.cart.clear();
    state
        .connection
        .set(format!("user:{}", user.username), user)
        .await
        .map_err(internal_error)?;

    Ok(StatusCode::OK)
}

#[derive(Serialize, Deserialize, Eq, PartialEq, Validate)]
pub struct ListOrders {
    login_data: UserLoginData,
}

pub async fn list_orders(
    State(mut state): State<AppState>,
    Json(payload): Json<ListOrders>,
) -> Result<(StatusCode, Json<Vec<Order>>), (StatusCode, String)> {
    payload
        .validate()
        .map_err(|e| (StatusCode::BAD_REQUEST, format!("Bad Request: {}", e)))?;

    if !state
        .connection
        .exists(format!("user:{}", payload.login_data.username))
        .await
        .map_err(internal_error)?
    {
        return Err((StatusCode::NOT_FOUND, String::from("User Doesn't Exists")));
    }

    let user: User = state
        .connection
        .get(format!("user:{}", payload.login_data.username))
        .await
        .map_err(internal_error)?;

    if user.token != payload.login_data.token {
        return Err((
            StatusCode::UNAUTHORIZED,
            String::from("Password doesn't match"),
        ));
    }

    Ok((StatusCode::OK, Json(user.orders)))
}

#[derive(Serialize, Deserialize, Clone, Debug, Validate)]
pub struct UsernameAndOrder {
    username: String,
    order: Vec<Order>,
}

#[derive(Serialize, Deserialize, Eq, PartialEq, Validate)]
pub struct ListAllOrdersAdmin {
    login_data: UserLoginData,
}

pub async fn list_all_orders_admin(
    State(mut state): State<AppState>,
    Json(payload): Json<ListAllOrdersAdmin>,
) -> Result<(StatusCode, Json<Vec<UsernameAndOrder>>), (StatusCode, String)> {
    payload
        .validate()
        .map_err(|e| (StatusCode::BAD_REQUEST, format!("Bad Request: {}", e)))?;

    if !state
        .connection
        .exists(format!("user:{}", payload.login_data.username))
        .await
        .map_err(internal_error)?
    {
        return Err((StatusCode::NOT_FOUND, String::from("User Doesn't Exists")));
    }

    let user: User = state
        .connection
        .get(format!("user:{}", payload.login_data.username))
        .await
        .map_err(internal_error)?;

    if user.token != payload.login_data.token {
        return Err((
            StatusCode::UNAUTHORIZED,
            String::from("Password doesn't match"),
        ));
    }

    if !user.admin {
        return Err((StatusCode::FORBIDDEN, String::from("User is not admin")));
    }

    let mut result = Vec::new();
    let keys: Vec<String> = state
        .connection
        .keys("user:*")
        .await
        .map_err(internal_error)?;

    for key in keys {
        let user: User = state.connection.get(key).await.map_err(internal_error)?;
        result.push(UsernameAndOrder {
            username: user.username,
            order: user.orders,
        });
    }

    Ok((StatusCode::OK, Json(result)))
}

#[derive(Serialize, Deserialize, Clone, Debug, Validate)]
pub struct UsernameAndSingleOrder {
    username: String,
    order: Order,
}

#[derive(Serialize, Deserialize, Clone, Debug, Validate)]
pub struct SetOrderStage {
    login_data: UserLoginData,
    username_and_order: UsernameAndSingleOrder,
    new_stage: String,
}

pub async fn set_order_stage(
    State(mut state): State<AppState>,
    Json(payload): Json<SetOrderStage>,
) -> Result<StatusCode, (StatusCode, String)> {
    payload
        .validate()
        .map_err(|e| (StatusCode::BAD_REQUEST, format!("Bad Request: {}", e)))?;

    if !state
        .connection
        .exists(format!("user:{}", payload.login_data.username))
        .await
        .map_err(internal_error)?
    {
        return Err((StatusCode::NOT_FOUND, String::from("User Doesn't Exists")));
    }

    let user: User = state
        .connection
        .get(format!("user:{}", payload.login_data.username))
        .await
        .map_err(internal_error)?;

    if user.token != payload.login_data.token {
        return Err((
            StatusCode::UNAUTHORIZED,
            String::from("Password doesn't match"),
        ));
    }

    if !user.admin {
        return Err((StatusCode::FORBIDDEN, String::from("User is not admin")));
    }

    let mut user: User = state
        .connection
        .get(format!("user:{}", payload.username_and_order.username))
        .await
        .map_err(internal_error)?;

    let mut found = false;
    for order in &mut user.orders {
        if *order == payload.username_and_order.order {
            order.stage = payload.new_stage.clone();
            found = true;
            break;
        }
    }

    if !found {
        return Err((StatusCode::NOT_FOUND, String::from("Order was not found")));
    }

    state
        .connection
        .set(format!("user:{}", user.username), user)
        .await
        .map_err(internal_error)?;

    Ok(StatusCode::OK)
}
