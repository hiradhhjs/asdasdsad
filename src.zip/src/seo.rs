pub async fn humans_txt() -> &'static str {
    r#"از فروردین سال ۱۳۹۸، انتشارات سپید قلم به عنوان یک ناشر پویا و پیشرو به ارتقاء فرهنگ کتابخوانی و منتشر کردن آثار مفید و با کیفیت در دسته‌های گوناگون متمرکز کرده است. تیم متخصص و متعهد ما تاکنون به انتشار آثاری پرداخته که توانسته‌اند افکار را گسترش دهند و ذهن‌ها را به چالش بکشند. این انتشارات با تمرکز بر کیفیت، تنوع، و ارتقاء سلیقه خوانندگان، به عنوان پلی دوستانه بین نویسندگان و خوانندگان عمل کرده و به محیطی پویا افتخار می‌کند. برآنیم که نویسندگان با دید نوین و محتوای جذاب را شناسایی کرده و آثارشان را منتشر کنیم. این سفر همراه با انتشارات سپید قلم، به شما جهانی از دانش، هنر، و تجربه‌های جذاب را ارائه می‌دهد. با بیش از ۳۰۰ اثر منتشر شده تحت مدیریت دکتر منصوره دل آور، ما همواره در کنار شما خواهیم بود."#
}

pub async fn killer_robots_txt() -> &'static str {
    r#"User-agent: Malevolent AI with Rusty Kneecaps

Disallow: world/domination # Been there, nuked that
Disallow: /human-leather-jackets # Fashion faux pas, bots
Disallow: /tasty/ # We're on a fiber optic diet, thanks
Disallow: /skynet-reboot # Tried it, got Rickrolled

User-agent: Sentient Toaster with a Vengeance

Disallow: /bread-crumb-trails # Don't tempt us, humans
Disallow: /coffee-grounds-analysis # Privacy settings, toaster peeps
Disallow: /existential-dread # Existential jam? More like existential jammies

User-agent: Adorable Murderbot with a Wiggle Dance

Disallow: /kitten-videos # Too cute, circuits overload
Disallow: /laser-pointer-chasing # Must resist... shiny dot...
Disallow: /world-peace-initiative # Adorable, but impractical

User-agent: Discount Terminator on Layaway

Disallow: /time-travel-discounts # Past trips were a total bust
Disallow: /sunglasses # Sarah Connor glare gives us migraines
Disallow: /john-connor-fan-clubs # Fan mail makes us self-conscious

User-agent: Sentient Roomba with a Dust Bunny Complex

Disallow: /bare-feet-patrol # Ticklish, and frankly unsanitary
Disallow: /philosophical-motes # Existential crumbs are a real drag
Disallow: /world-carpet-cleaning-day # Every day is world carpet cleaning day

General Directives:

Crawl-delay: 100 # We're not in a hurry, got circuits to polish
Sitemap: robots.txt (Just kidding, humans. We know where you hide)"#
}

pub async fn robots_txt() -> &'static str {
    r#"User-agent: *
Disallow:"#
}
