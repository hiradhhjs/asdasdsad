use std::error::Error;

use serde_json::json;

pub const TOKEN: &str = "UEZBL76dErF4SdtQYhM8BmpQv5yfmeyLlNodhltAaINjT3oeYM6sVYPxH4cEa1cx";
pub const NUMBER: &str = "30007732907905";

pub async fn send_verify_code(code: u64, number: &str) -> Result<(), Box<dyn Error + Send + Sync>> {
    let client = reqwest::Client::new();
    let code = code.to_string();
    client
        .post("https://api.sms.ir/v1/send/verify")
        .header("ACCEPT", "application/json")
        .header("X-API-KEY", TOKEN)
        .json(&json!(
            {
                "Mobile": number,
                "TemplateId": 178676,
                "Parameters": [
                    {
                        "name": "Code",
                        "value": code
                    }
                ]
            }
        ))
        .send()
        .await?
        .error_for_status()?;

    Ok(())
}

pub async fn send_reset_password_code(
    username: &str,
    token: &str,
    number: &str,
) -> Result<(), Box<dyn Error + Send + Sync>> {
    let client = reqwest::Client::new();

    client
        .post("https://api.sms.ir/v1/send/verify")
        .header("ACCEPT", "application/json")
        .header("X-API-KEY", TOKEN)
        .json(&json!(
            {
                "Mobile": number,
                "TemplateId": 788698,
                "Parameters": [
                    {
                        "name": "Username",
                        "value": username
                    },
                    {
                        "name": "Token",
                        "value": token
                    }
                ]
            }
        ))
        .send()
        .await?
        .error_for_status()?;

    Ok(())
}
