pub mod cart;
pub mod discord;
pub mod manage;
pub mod posts;
pub mod seo;
pub mod slider;
pub mod sms;
pub mod user;
pub mod enamad;

use std::{collections::HashMap, error::Error, sync::Arc};

use axum::http::StatusCode;
use moka::future::Cache;
use posts::Post;
use redis::aio::ConnectionManager;
use slider::Slider;
use tokio::sync::Mutex;
use tracing::error;
use user::User;

#[derive(Clone)]
pub struct AppState {
    pub connection: ConnectionManager,
    pub cache_handler: CacheHandler,
    pub verification: Arc<Mutex<HashMap<(String, u64), User>>>,
    #[allow(clippy::type_complexity)]
    pub reset_password_verification: Arc<Mutex<HashMap<String, User>>>,
    pub phone_number_time_limit: Arc<Mutex<Vec<String>>>,
}

type PostKeyCache = (
    u32,
    u32,
    bool,
    bool,
    bool,
    bool,
    Option<String>,
    Option<String>,
);
type PostSizeCache = (Option<bool>, Option<bool>, Option<String>, Option<String>);
#[derive(Clone)]
pub struct CacheHandler {
    pub list_posts_cache: Cache<PostKeyCache, Vec<Post>>,
    pub posts_cache: Cache<String, Post>,
    pub slider_cache: Arc<Mutex<Option<Vec<Slider>>>>,
    pub cache_size: Cache<PostSizeCache, usize>,
}

#[derive(Clone)]
pub struct Stats {
    pub list_posts_cache: Cache<PostKeyCache, Vec<Post>>,
}

pub fn critical_error<E: Error + Send + Sync + 'static>(_: &str) {
    error!("Critical Error");

    std::process::exit(-1);
}

pub fn internal_error<E: Error + Send + Sync + 'static>(err: E) -> (StatusCode, String) {
    error!("Internal Error: {err}");

    (
        StatusCode::INTERNAL_SERVER_ERROR,
        String::from("500 Internal Server Error [RFC7231, Section 6.6.1]"),
    )
}

pub fn internal_error_boxed<E: Error + Send + Sync + 'static + ?Sized>(
    err: Box<E>,
) -> (StatusCode, String) {
    let err = Box::new(err);

    error!("Internal Error: {err}");

    (
        StatusCode::INTERNAL_SERVER_ERROR,
        String::from("500 Internal Server Error [RFC7231, Section 6.6.1]"),
    )
}
