#![warn(clippy::nursery)]

use std::{collections::HashMap, sync::Arc, time::Duration};

use axum::{
    extract::DefaultBodyLimit,
    http::{HeaderValue, Method},
    routing::{delete, get, post},
    Router,
};
use moka::future::Cache;
use rand::{distributions::Alphanumeric, Rng};
use redis::{aio::ConnectionManager, AsyncCommands};
use tokio::{net::TcpListener, sync::Mutex};
use tower_http::{
    catch_panic::CatchPanicLayer,
    cors::{Any, CorsLayer},
    services::{ServeDir, ServeFile},
    timeout::TimeoutLayer,
};
use tracing::{error, info};
use wredis::{
    cart::{
        add_to_cart, buy_cart, delete_all_from_cart, delete_from_cart, get_cart_price,
        list_all_orders_admin, list_cart, list_orders, set_order_stage,
    },
    enamad::enamad_301285,
    manage::{count_post, count_slider, count_user},
    posts::{
        create_post, delete_post, get_post, list_post, modify_discount, modify_price, modify_stock,
        search_post,
    },
    seo::{humans_txt, killer_robots_txt, robots_txt},
    slider::{create_slider, delete_slider, list_slider},
    user::{
        create_user, get_address_info, is_admin, is_reset_password_verification_token_valid,
        login_user, reset_password, set_address_info, verify_reset_password, verify_user, User,
    },
    AppState, CacheHandler,
};

#[tokio::main]
async fn main() {
    // Logging
    tracing_subscriber::fmt::fmt()
        .with_env_filter("info")
        .without_time()
        .pretty()
        .init();

    // Data Base
    info!("Connecting to database");
    let client = match redis::Client::open("redis://127.0.0.1:6379") {
        Ok(client) => client,
        Err(e) => {
            error!("Failed to connect to database: {}", e);
            return;
        }
    };

    let mut connection = match ConnectionManager::new(client).await {
        Ok(connection) => connection,
        Err(e) => {
            error!("Failed to initialize connection manager: {}", e);
            return;
        }
    };

    // Setup Admin
    let user = User {
        username: String::from("Mansooredelavaradmin"),
        password: String::from("FwZY7-Qmy14u9lezJ-6H6MmBp0u"),
        phone_number: String::from("+980000000000"),
        token: rand::thread_rng()
            .sample_iter(&Alphanumeric)
            .take(18)
            .map(char::from)
            .collect(),
        admin: true,
        cart: HashMap::new(),
        bought: Vec::new(),
        address_info: None,
        orders: Vec::new(),
    };

    match connection
        .set(format!("user:{}", user.username), user)
        .await
    {
        Ok(()) => (),
        Err(e) => {
            error!("Failed to setup admin: {}", e);
            return;
        }
    };

    // Cache
    let app_state = AppState {
        connection,
        cache_handler: CacheHandler {
            list_posts_cache: Cache::builder()
                .max_capacity(90)
                .time_to_live(Duration::from_secs(24 * 60 * 60))
                .time_to_idle(Duration::from_secs(18 * 60 * 60))
                .support_invalidation_closures()
                .build(),
            posts_cache: Cache::builder()
                .max_capacity(900)
                .time_to_live(Duration::from_secs(24 * 60 * 60))
                .time_to_idle(Duration::from_secs(18 * 60 * 60))
                .support_invalidation_closures()
                .build(),
            slider_cache: Arc::new(Mutex::new(None)),
            cache_size: Cache::builder()
                .max_capacity(90)
                .time_to_live(Duration::from_secs(24 * 60 * 60))
                .time_to_idle(Duration::from_secs(18 * 60 * 60))
                .build(),
        },
        verification: Arc::new(Mutex::new(HashMap::new())),
        reset_password_verification: Arc::new(Mutex::new(HashMap::new())),
        phone_number_time_limit: Arc::new(Mutex::new(Vec::new())),
    };

    info!("Starting Api");
    // Cors
    let cors_layer = CorsLayer::new()
        .allow_origin("https://sepidghalam.ir/".parse::<HeaderValue>().unwrap())
        .allow_methods([Method::GET, Method::POST, Method::DELETE])
        .allow_headers(Any);

    // let cors_layer = CorsLayer::new()
    //     .allow_origin(Any)
    //     .allow_methods(Any)
    //     .allow_headers(Any);

    // Router
    let app: Router = Router::new()
        // Seo
        .route("/humans.txt", get(humans_txt))
        .route("/killer-robots.txt", get(killer_robots_txt))
        .route("/robots.txt", get(robots_txt))
        // Enamad
        .route("/301285.txt", get(enamad_301285))
        // Admin Api
        .route("/api/admin/is_admin", post(is_admin))
        // Admin Post Api
        .route("/api/admin/posts/create", post(create_post))
        .route("/api/admin/posts/delete", delete(delete_post))
        // Admin Slider Api
        .route("/api/admin/slider/create", post(create_slider))
        .route("/api/admin/slider/delete", delete(delete_slider))
        // Admin Statistics Api
        .route("/api/admin/stats/count_user", post(count_user))
        .route("/api/admin/stats/count_post", post(count_post))
        .route("/api/admin/stats/count_slider", post(count_slider))
        // User Post Api
        .route("/api/posts/get", post(get_post))
        .route("/api/posts/list", post(list_post))
        .route("/api/posts/search", post(search_post))
        .route("/api/posts/modify_price", post(modify_price))
        .route("/api/posts/modify_discount", post(modify_discount))
        .route("/api/posts/modify_stock", post(modify_stock))
        // User Shopping Cart Api
        .route("/api/cart/add", post(add_to_cart))
        .route("/api/cart/delete", post(delete_from_cart))
        .route("/api/cart/list", post(list_cart))
        .route("/api/cart/delete_all", post(delete_all_from_cart))
        .route("/api/cart/price", post(get_cart_price))
        .route("/api/cart/buy", post(buy_cart))
        .route("/api/cart/list_orders", post(list_orders))
        .route("/api/cart/list_all_orders_admin", post(list_all_orders_admin))
        .route("/api/cart/set_order_stage", post(set_order_stage))
        // User Slider Api
        .route("/api/slider/list", get(list_slider))
        // User Management Api
        .route("/api/users/register", post(create_user))
        .route("/api/users/verify", post(verify_user))
        .route("/api/users/login", post(login_user))
        .route("/api/users/reset_password", post(reset_password))
        .route("/api/users/verify_reset_password", post(verify_reset_password))
        .route("/api/users/is_reset_password_verification_token_valid", post(is_reset_password_verification_token_valid))
        .route("/api/users/set_address_info", post(set_address_info))
        .route("/api/users/get_address_info", post(get_address_info))
        // Fallback Api
        .fallback_service(ServeDir::new("./dist").not_found_service(ServeFile::new("./dist/index.html")))
        // State
        .with_state(app_state)
        // Middlewares
        .layer(DefaultBodyLimit::max(1024 * 1024 * 8))
        .layer(CatchPanicLayer::new())
        .layer(TimeoutLayer::new(Duration::from_secs(60)))
        .layer(cors_layer);

    let listener = match TcpListener::bind("0.0.0.0:6969").await {
        Ok(listener) => listener,
        Err(e) => {
            error!("Failed to bind to port 6969: {}", e);
            return;
        }
    };

    match axum::serve(listener, app).await {
        Ok(()) => info!("Server stopped"),
        Err(e) => error!("Server crashed: {}", e),
    };
}
