use serenity::{
    builder::{CreateAttachment, ExecuteWebhook},
    http::Http,
    model::webhook::Webhook,
};

use crate::posts::Post;

pub const WEBHOOK: &str = "https://discord.com/api/webhooks/1196483858913300551/9lIWVFVHYwdE8i0o3B53dz617Z1DCYAcXCBL2uAh7drNwPmQZZjx9YcvT6IqBezxBqvC";

pub async fn send_webhook(mut post: Post) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    let http = Http::new("");
    let webhook = Webhook::from_url(&http, WEBHOOK).await?;

    let mut attachments = Vec::new();

    if post.file.is_some() {
        let file = post.clone().file.unwrap();
        let attachment = CreateAttachment::bytes(file, "File.data");
        attachments.push(attachment);
    }

    if post.image.is_some() {
        let image = post.clone().image.unwrap();
        let attachment = CreateAttachment::bytes(image, "Image.data");
        attachments.push(attachment);
    }

    post.image = None;
    post.file = None;

    let builder = ExecuteWebhook::new()
        .content(format!(
            "```js\n{}\n```",
            serde_json::to_string_pretty(&post)?
        ))
        .add_files(attachments)
        .username("Backup")
        .avatar_url("https://avatars.githubusercontent.com/u/3313892?v=4");

    webhook.execute(&http, false, builder).await?;

    Ok(())
}
